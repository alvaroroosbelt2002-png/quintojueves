package com.yj.tinventario.activities.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.yj.tinventario.R;
import java.util.Random;

public class PromoteToSupervisorActivity extends AppCompatActivity {

    private TextView tvUsuarioPromover, tvCodigoGenerado;
    private Button btnGenerarCodigo;

    private String userId;
    private String userEmail;

    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promote_to_supervisor);

        Intent intent = getIntent();
        userId = intent.getStringExtra("userId");
        userEmail = intent.getStringExtra("userEmail");

        tvUsuarioPromover = findViewById(R.id.tvUsuarioPromover);
        tvCodigoGenerado = findViewById(R.id.tvCodigoGenerado);
        btnGenerarCodigo = findViewById(R.id.btnGenerarCodigo);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        tvUsuarioPromover.setText("Usuario: " + userEmail);

        btnGenerarCodigo.setOnClickListener(v -> generarYGuardarCodigo());
    }

    private void generarYGuardarCodigo() {
        Random random = new Random();
        int codigo = 100000 + random.nextInt(900000);
        String codigoGenerado = String.valueOf(codigo);

        // Guardar el código de promoción y cambiar el rol a 'Supervisor'
        mDatabase.child("users").child(userId).child("accessCode").setValue(codigoGenerado)
                .addOnSuccessListener(aVoid -> {
                    mDatabase.child("users").child(userId).child("role").setValue("Supervisor")
                            .addOnSuccessListener(task -> {
                                Toast.makeText(this, "Código de acceso permanente generado y guardado para " + userEmail, Toast.LENGTH_SHORT).show();
                                tvCodigoGenerado.setText("El código de acceso para " + userEmail + " es: \n" + codigoGenerado);
                                tvCodigoGenerado.setVisibility(View.VISIBLE);
                                btnGenerarCodigo.setVisibility(View.GONE);
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(this, "Error al actualizar el rol: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al guardar el código: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}