package com.yj.tinventario.activities.admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.yj.tinventario.R;
import com.yj.tinventario.adapters.UserAdapter;
import com.yj.tinventario.models.User;

import java.util.ArrayList;
import java.util.List;

public class UserManagementActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private UserAdapter adapter;
    private List<User> userList;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_management);

        mDatabase = FirebaseDatabase.getInstance().getReference("users");

        recyclerView = findViewById(R.id.recyclerViewUsuarios);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        userList = new ArrayList<>();
        adapter = new UserAdapter(userList, new UserAdapter.OnItemClickListener() {
            @Override
            public void onPromoteClick(User user) {
                // Lógica existente para promover a supervisor
                Intent intent = new Intent(UserManagementActivity.this, PromoteToSupervisorActivity.class);
                intent.putExtra("userId", user.getUserId());
                intent.putExtra("userEmail", user.getEmail());
                startActivity(intent);
            }

            // Dentro de la clase pública UserManagementActivity
            @Override
            public void onDemoteClick(User user) {
                // Lógica para degradar con confirmación
                // CAMBIO AQUI: Usar equalsIgnoreCase() para una comparación que no distingue entre mayúsculas y minúsculas
                if ("supervisor".equalsIgnoreCase(user.getRole())) {
                    new AlertDialog.Builder(UserManagementActivity.this)
                            .setTitle("Confirmar Degradación")
                            .setMessage("¿Está seguro de que desea degradar a " + user.getNombre() + " " + user.getApellido() + " a Instructor?")
                            .setPositiveButton("Sí, degradar", (dialog, which) -> {
                                // Si el usuario confirma, se cambia el rol en Firebase
                                mDatabase.child(user.getUserId()).child("role").setValue("instructor")
                                        .addOnSuccessListener(aVoid -> Toast.makeText(UserManagementActivity.this, "Rol de " + user.getNombre() + " cambiado a instructor.", Toast.LENGTH_SHORT).show())
                                        .addOnFailureListener(e -> Toast.makeText(UserManagementActivity.this, "Error al cambiar el rol.", Toast.LENGTH_SHORT).show());
                            })
                            .setNegativeButton("Cancelar", null) // No hace nada si el usuario cancela
                            .show();
                } else {
                    Toast.makeText(UserManagementActivity.this, "No se puede degradar a este usuario.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        recyclerView.setAdapter(adapter);

        loadUsersFromFirebase();
    }

    private void loadUsersFromFirebase() {
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                userList.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    User user = postSnapshot.getValue(User.class);
                    if (user != null) {
                        user.setUserId(postSnapshot.getKey());
                        if (!"admin".equals(user.getRole())) {
                            userList.add(user);
                        }
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(UserManagementActivity.this, "Error al cargar usuarios: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}