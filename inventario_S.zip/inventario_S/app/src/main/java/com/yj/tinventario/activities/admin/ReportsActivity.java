
package com.yj.tinventario.activities.admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yj.tinventario.R;
import com.yj.tinventario.models.LoanRequest;
import com.yj.tinventario.models.Product;
import com.yj.tinventario.models.User;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ReportsActivity extends AppCompatActivity {

    private TextView tvTotalProductos, tvTotalPrestamos, tvPrestamosPendientes, tvTopProducts;
    private Button btnActualizarReporte, btnGenerarPDF, btnCompartirPDF; // Nuevo botón
    private DatabaseReference mDatabase;

    private List<Product> productList = new ArrayList<>();
    private List<LoanRequest> loanRequestList = new ArrayList<>();
    private Map<String, String> productNames = new HashMap<>();
    private Map<String, String> userNames = new HashMap<>();
    private File pdfFile; // Variable para almacenar el archivo PDF

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        tvTotalProductos = findViewById(R.id.tvTotalProductos);
        tvTotalPrestamos = findViewById(R.id.tvTotalPrestamos);
        tvPrestamosPendientes = findViewById(R.id.tvPrestamosPendientes);
        tvTopProducts = findViewById(R.id.tvTopProducts);
        btnActualizarReporte = findViewById(R.id.btnActualizarReporte);
        btnGenerarPDF = findViewById(R.id.btnGenerarPDF);
        btnCompartirPDF = findViewById(R.id.btnCompartirPDF); // Inicializar el nuevo botón

        mDatabase = FirebaseDatabase.getInstance().getReference();

        loadReports();

        btnActualizarReporte.setOnClickListener(v -> loadReports());
        btnGenerarPDF.setOnClickListener(v -> generatePdfReport());
        btnCompartirPDF.setOnClickListener(v -> sharePdf()); // Nuevo listener
    }

    private void loadReports() {
        mDatabase.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot userSnapshot) {
                userNames.clear();
                for (DataSnapshot userData : userSnapshot.getChildren()) {
                    String userId = userData.getKey();
                    User user = userData.getValue(User.class);
                    if (userId != null && user != null) {
                        userNames.put(userId, user.getNombre() + " " + user.getApellido());
                    }
                }
                loadProductsAndLoans();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(ReportsActivity.this, "Error al cargar usuarios: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadProductsAndLoans() {
        mDatabase.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot productSnapshot) {
                productList.clear();
                productNames.clear();
                for (DataSnapshot productData : productSnapshot.getChildren()) {
                    Product product = productData.getValue(Product.class);
                    if (product != null) {
                        String productId = productData.getKey();
                        product.setProductId(productId);
                        productList.add(product);
                        productNames.put(product.getProductId(), product.getName());
                    }
                }
                updateLoanReport();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(ReportsActivity.this, "Error al cargar productos: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateLoanReport() {
        mDatabase.child("loan_requests").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot requestSnapshot) {
                loanRequestList.clear();
                int totalPrestamos = 0;
                int prestamosPendientes = 0;
                Map<String, Integer> productLoanCount = new HashMap<>();

                for (DataSnapshot requestData : requestSnapshot.getChildren()) {
                    LoanRequest request = requestData.getValue(LoanRequest.class);
                    if (request != null) {
                        loanRequestList.add(request);

                        if ("aprobado".equalsIgnoreCase(request.getStatus()) || "devuelto".equalsIgnoreCase(request.getStatus())) {
                            totalPrestamos++;
                            int count = productLoanCount.getOrDefault(request.getProductId(), 0);
                            productLoanCount.put(request.getProductId(), count + 1);
                        } else if ("pendiente".equalsIgnoreCase(request.getStatus())) {
                            prestamosPendientes++;
                        }
                    }
                }

                tvTotalProductos.setText("Total de Productos: " + productList.size());
                tvTotalPrestamos.setText("Total de Préstamos Realizados: " + totalPrestamos);
                tvPrestamosPendientes.setText("Préstamos Pendientes: " + prestamosPendientes);

                List<Map.Entry<String, Integer>> sortedProducts = new ArrayList<>(productLoanCount.entrySet());
                sortedProducts.sort((a, b) -> b.getValue().compareTo(a.getValue()));

                StringBuilder topProductsText = new StringBuilder("Productos más prestados:\n");
                int count = 0;
                for (Map.Entry<String, Integer> entry : sortedProducts) {
                    if (count >= 3) break;
                    topProductsText.append(count + 1)
                            .append(". ")
                            .append(productNames.getOrDefault(entry.getKey(), "Desconocido"))
                            .append(" (")
                            .append(entry.getValue())
                            .append(")\n");
                    count++;
                }
                tvTopProducts.setText(topProductsText.toString());
                Toast.makeText(ReportsActivity.this, "Reportes actualizados.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(ReportsActivity.this, "Error al cargar solicitudes: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void generatePdfReport() {
        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(842, 595, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();

        int x = 40;
        int y = 50;
        int lineHeight = 20;

        paint.setTextSize(24);
        paint.setFakeBoldText(true);
        canvas.drawText("Reporte Detallado de Préstamos", x, y, paint);
        y += lineHeight * 2;

        paint.setTextSize(12);
        paint.setFakeBoldText(true);
        canvas.drawText("ID Solicitud", 40, y, paint);
        canvas.drawText("Producto", 140, y, paint);
        canvas.drawText("Usuario", 300, y, paint);
        canvas.drawText("Cantidad", 480, y, paint);
        canvas.drawText("Estado", 580, y, paint);
        canvas.drawText("Fecha", 680, y, paint);
        y += lineHeight;

        paint.setFakeBoldText(false);

        for (LoanRequest request : loanRequestList) {
            canvas.drawText(request.getRequestId(), 40, y, paint);
            canvas.drawText(productNames.getOrDefault(request.getProductId(), "Desconocido"), 140, y, paint);
            canvas.drawText(userNames.getOrDefault(request.getUserId(), "Desconocido"), 300, y, paint);
            canvas.drawText(String.valueOf(request.getQuantity()), 480, y, paint);
            canvas.drawText(request.getStatus(), 580, y, paint);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            String date = dateFormat.format(new Date(request.getTimestamp()));
            canvas.drawText(date, 680, y, paint);

            y += lineHeight;

            if (y > 550) {
                document.finishPage(page);
                page = document.startPage(pageInfo);
                canvas = page.getCanvas();
                y = 50;
                paint.setTextSize(12);
                paint.setFakeBoldText(true);
                canvas.drawText("ID Solicitud", 40, y, paint);
                canvas.drawText("Producto", 140, y, paint);
                canvas.drawText("Usuario", 300, y, paint);
                canvas.drawText("Cantidad", 480, y, paint);
                canvas.drawText("Estado", 580, y, paint);
                canvas.drawText("Fecha", 680, y, paint);
                y += lineHeight;
                paint.setFakeBoldText(false);
            }
        }

        document.finishPage(page);

        // Guardar el PDF y habilitar el botón de compartir
        String fileName = "Reporte_Detallado_" + System.currentTimeMillis() + ".pdf";
        pdfFile = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName); // Guardar la referencia al archivo
        try {
            document.writeTo(new FileOutputStream(pdfFile));
            Toast.makeText(this, "PDF guardado en: " + pdfFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
            btnCompartirPDF.setVisibility(View.VISIBLE); // Hacer visible el botón de compartir
        } catch (IOException e) {
            Toast.makeText(this, "Error al generar el PDF: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            btnCompartirPDF.setVisibility(View.GONE); // Asegurarse de que el botón no sea visible si falla
        } finally {
            document.close();
        }
    }

    // Nuevo método para compartir el PDF
    private void sharePdf() {
        if (pdfFile != null && pdfFile.exists()) {
            Uri pdfUri = FileProvider.getUriForFile(
                    ReportsActivity.this,
                    "com.yj.tinventario.fileprovider", // Debe coincidir con el valor en AndroidManifest.xml
                    pdfFile
            );

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/pdf");
            shareIntent.putExtra(Intent.EXTRA_STREAM, pdfUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); // Conceder permisos temporales
            startActivity(Intent.createChooser(shareIntent, "Compartir Reporte PDF"));
        } else {
            Toast.makeText(this, "El PDF no se ha generado todavía. Por favor, genérelo primero.", Toast.LENGTH_SHORT).show();
        }
    }
}