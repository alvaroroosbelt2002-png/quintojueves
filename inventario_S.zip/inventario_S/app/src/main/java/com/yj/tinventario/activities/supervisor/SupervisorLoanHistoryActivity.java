package com.yj.tinventario.activities.supervisor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yj.tinventario.R;
import com.yj.tinventario.adapters.SupervisorLoanHistoryAdapter;
import com.yj.tinventario.models.LoanRequest;
import com.yj.tinventario.models.User;
import com.yj.tinventario.models.Product;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SupervisorLoanHistoryActivity extends AppCompatActivity implements SupervisorLoanHistoryAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private SupervisorLoanHistoryAdapter adapter;
    private List<LoanRequest> allLoanRequestsList;
    private List<LoanRequest> filteredLoanRequestsList;
    private Spinner spinnerFiltroEstado;

    private DatabaseReference mDatabase;
    private DatabaseReference usersDatabase;
    private DatabaseReference productsDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supervisor_loan_history);

        mDatabase = FirebaseDatabase.getInstance().getReference("loan_requests");
        usersDatabase = FirebaseDatabase.getInstance().getReference("users");
        productsDatabase = FirebaseDatabase.getInstance().getReference("products");

        recyclerView = findViewById(R.id.recyclerViewHistorialSupervisor);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        allLoanRequestsList = new ArrayList<>();
        filteredLoanRequestsList = new ArrayList<>();

        adapter = new SupervisorLoanHistoryAdapter(filteredLoanRequestsList, this);
        recyclerView.setAdapter(adapter);

        spinnerFiltroEstado = findViewById(R.id.spinnerFiltroEstado);
        setupSpinner();

        loadAllLoanRequestsData();

        spinnerFiltroEstado.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedStatus = parent.getItemAtPosition(position).toString();
                filterLoanRequests(selectedStatus);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No action needed
            }
        });
    }

    /**
     * Configura el Spinner con las opciones de estado de los préstamos.
     */
    private void setupSpinner() {
        String[] statuses = new String[]{"Todos", "Pendiente", "Aprobado", "Rechazado", "Devuelto"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, statuses);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFiltroEstado.setAdapter(adapter);
    }

    /**
     * Carga todos los datos de los préstamos desde Firebase.
     */
    private void loadAllLoanRequestsData() {
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                allLoanRequestsList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    LoanRequest request = snapshot.getValue(LoanRequest.class);
                    if (request != null) {
                        request.setRequestId(snapshot.getKey());
                        allLoanRequestsList.add(request);
                    }
                }
                filteredLoanRequestsList.clear();
                filteredLoanRequestsList.addAll(allLoanRequestsList);
                adapter.notifyDataSetChanged();
                Log.d("SupervisorHistorial", "Préstamos cargados: " + allLoanRequestsList.size());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("SupervisorHistorial", "Error al cargar datos: " + databaseError.getMessage());
                Toast.makeText(SupervisorLoanHistoryActivity.this, "Error al cargar el historial.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Filtra la lista de préstamos basándose en el estado seleccionado.
     * @param status El estado por el que se desea filtrar.
     */
    private void filterLoanRequests(String status) {
        filteredLoanRequestsList.clear(); // Limpia la lista antes de volver a llenarla
        if (status.equals("Todos")) {
            filteredLoanRequestsList.addAll(allLoanRequestsList); // Muestra todos los datos
        } else {
            String lowercaseStatus = status.toLowerCase();
            for (LoanRequest request : allLoanRequestsList) { // Filtra desde la lista original
                if (request.getStatus() != null && request.getStatus().equals(lowercaseStatus)) {
                    filteredLoanRequestsList.add(request);
                }
            }
        }
        adapter.notifyDataSetChanged(); // Notifica al adaptador del cambio
    }

    @Override
    public void onItemClick(LoanRequest request) {
        showDetailsDialog(request);
    }

    private void showDetailsDialog(LoanRequest request) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_loan_details, null);
        builder.setView(dialogView);

        TextView tvSolicitante = dialogView.findViewById(R.id.tvDialogSolicitante);
        TextView tvProducto = dialogView.findViewById(R.id.tvDialogProducto);
        TextView tvCantidad = dialogView.findViewById(R.id.tvDialogCantidad);
        TextView tvEstado = dialogView.findViewById(R.id.tvDialogEstado);
        ImageView ivEvidencia = dialogView.findViewById(R.id.ivDialogEvidencia);
        TextView tvNoImage = dialogView.findViewById(R.id.tvNoImage);

        // Cargar datos de usuario y producto de forma asíncrona
        loadUserData(request.getUserId(), tvSolicitante);
        loadProductData(request.getProductId(), tvProducto);

        tvCantidad.setText("Cantidad: " + request.getQuantity());

        // Verifica que el estado no sea nulo antes de manipularlo
        String estadoTexto = request.getStatus() != null ?
                request.getStatus().substring(0, 1).toUpperCase() + request.getStatus().substring(1) :
                "Desconocido";
        tvEstado.setText("Estado: " + estadoTexto);

        // Cargar imagen de evidencia si existe
        if (request.getPhotoUrl() != null && !request.getPhotoUrl().isEmpty()) {
            ivEvidencia.setVisibility(View.VISIBLE);
            tvNoImage.setVisibility(View.GONE);
            Glide.with(this).load(request.getPhotoUrl()).into(ivEvidencia);
        } else {
            ivEvidencia.setVisibility(View.GONE);
            tvNoImage.setVisibility(View.VISIBLE);
        }

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void loadUserData(String userId, TextView textView) {
        if (userId == null) {
            textView.setText("Solicitante: Usuario desconocido");
            return;
        }
        usersDatabase.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);
                if (user != null) {
                    textView.setText("Solicitante: " + user.getNombre() + " " + user.getApellido());
                } else {
                    textView.setText("Solicitante: Usuario desconocido");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                textView.setText("Solicitante: Error al cargar");
            }
        });
    }

    private void loadProductData(String productId, TextView textView) {
        if (productId == null) {
            textView.setText("Producto: Producto desconocido");
            return;
        }
        productsDatabase.child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Product product = dataSnapshot.getValue(Product.class);
                if (product != null) {
                    textView.setText("Producto: " + product.getName());
                } else {
                    textView.setText("Producto: Producto desconocido");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                textView.setText("Producto: Error al cargar");
            }
        });
    }
}