package com.yj.tinventario.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.yj.tinventario.R;
import com.yj.tinventario.models.User;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private final List<User> userList;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onPromoteClick(User user);
        void onDemoteClick(User user);
    }

    public UserAdapter(List<User> userList, OnItemClickListener listener) {
        this.userList = userList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = userList.get(position);
        holder.bind(user);
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        private final TextView tvNombreCompleto;
        private final TextView tvCorreoUsuario;
        private final TextView tvRolUsuario;
        private final Button btnPromover;
        private final Button btnDegradar;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombreCompleto = itemView.findViewById(R.id.tvNombreCompleto);
            tvCorreoUsuario = itemView.findViewById(R.id.tvCorreoUsuario);
            tvRolUsuario = itemView.findViewById(R.id.tvRolUsuario);
            btnPromover = itemView.findViewById(R.id.btnPromover);
            btnDegradar = itemView.findViewById(R.id.btnDegradar);

            btnPromover.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onPromoteClick(userList.get(position));
                }
            });

            btnDegradar.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onDemoteClick(userList.get(position));
                }
            });
        }

        public void bind(User user) {
            // Se añaden verificaciones para evitar NullPointerExceptions
            String nombre = user.getNombre() != null ? user.getNombre() : "";
            String apellido = user.getApellido() != null ? user.getApellido() : "";
            String email = user.getEmail() != null ? user.getEmail() : "";
            String role = user.getRole() != null ? user.getRole() : "";

            tvNombreCompleto.setText(nombre + " " + apellido);
            tvCorreoUsuario.setText(email);
            tvRolUsuario.setText("Rol: " + role);

            // Lógica para mostrar/ocultar los botones según el rol
            String userRole = role.toLowerCase();

            if ("instructor".equals(userRole)) {
                btnPromover.setVisibility(View.VISIBLE);
                btnDegradar.setVisibility(View.GONE);
            } else if ("supervisor".equals(userRole)) {
                btnPromover.setVisibility(View.GONE);
                btnDegradar.setVisibility(View.VISIBLE);
            } else {
                // Ocultar ambos botones si el rol es "admin" o cualquier otro
                btnPromover.setVisibility(View.GONE);
                btnDegradar.setVisibility(View.GONE);
            }
        }
    }
}