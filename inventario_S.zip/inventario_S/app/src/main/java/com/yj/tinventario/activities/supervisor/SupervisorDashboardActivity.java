package com.yj.tinventario.activities.supervisor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.yj.tinventario.R;
import com.yj.tinventario.activities.common.LoginActivity;

public class SupervisorDashboardActivity extends AppCompatActivity {

    private Button btnSolicitudesPendientes, btnDevolucionProducto, btnHistorialSupervisor, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supervisor_dashboard);

        // Inicializar vistas
        btnSolicitudesPendientes = findViewById(R.id.btnSolicitudesPendientes);
        btnDevolucionProducto = findViewById(R.id.btnDevolucionProducto);
        btnHistorialSupervisor = findViewById(R.id.btnHistorialSupervisor);
        btnLogout = findViewById(R.id.btnLogout);

        // Listener para el botón de Solicitudes Pendientes
        btnSolicitudesPendientes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SupervisorDashboardActivity.this, PendingRequestsActivity.class);
                startActivity(intent);
            }
        });

        // Listener para el botón de Devolución de Producto
        btnDevolucionProducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SupervisorDashboardActivity.this, ProductReturnActivity.class);
                startActivity(intent);
            }
        });

        // Listener para el botón de Historial de Transacciones
        btnHistorialSupervisor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SupervisorDashboardActivity.this, SupervisorLoanHistoryActivity.class);
                startActivity(intent);
            }
        });

        // Listener para el botón de Cerrar Sesión
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lógica para cerrar sesión
                Toast.makeText(SupervisorDashboardActivity.this, "Sesión de supervisor cerrada.", Toast.LENGTH_SHORT).show();

                // Navegar a la pantalla de Login y limpiar el historial
                Intent intent = new Intent(SupervisorDashboardActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}