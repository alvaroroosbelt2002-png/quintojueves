package com.yj.tinventario.activities.supervisor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.bumptech.glide.Glide; // Se agrega la librería Glide

import com.yj.tinventario.R;
import com.yj.tinventario.models.Product;
import com.yj.tinventario.models.User;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LoanApprovalActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int PERMISSION_CAMERA_CODE = 100;

    private TextView tvDetallesSolicitud;
    private ImageView ivEvidencia;
    private Button btnTomarFoto, btnAprobar, btnRechazar;
    private ProgressBar progressBar;
    private String requestId, userId, productId;
    private int quantity;
    private String currentPhotoPath;

    private DatabaseReference mDatabase;
    private StorageReference mStorageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan_approval);

        Intent intent = getIntent();
        requestId = intent.getStringExtra("requestId");
        userId = intent.getStringExtra("userId");
        productId = intent.getStringExtra("productId");
        quantity = intent.getIntExtra("quantity", 0);

        tvDetallesSolicitud = findViewById(R.id.tvDetallesSolicitud);
        ivEvidencia = findViewById(R.id.ivEvidencia);
        btnTomarFoto = findViewById(R.id.btnTomarFoto);
        btnAprobar = findViewById(R.id.btnAprobar);
        btnRechazar = findViewById(R.id.btnRechazar);
        progressBar = findViewById(R.id.progressBar);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        mStorageRef = FirebaseStorage.getInstance().getReference();

        loadRequestDetails();

        btnAprobar.setOnClickListener(v -> {
            if (currentPhotoPath == null) {
                Toast.makeText(LoanApprovalActivity.this, "Por favor, tome una foto como evidencia.", Toast.LENGTH_SHORT).show();
            } else {
                aprobarSolicitud();
            }
        });

        btnRechazar.setOnClickListener(v -> rechazarSolicitud());

        btnTomarFoto.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();
            } else {
                requestCameraPermission();
            }
        });
    }

    private void loadRequestDetails() {
        mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot userSnapshot) {
                User user = userSnapshot.getValue(User.class);
                String userName = (user != null) ? user.getNombre() + " " + user.getApellido() : "Desconocido";
                mDatabase.child("products").child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot productSnapshot) {
                        Product product = productSnapshot.getValue(Product.class);
                        String productName = (product != null) ? product.getName() : "Desconocido";
                        mostrarDetallesSolicitud(userName, productName);
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.e("LoanApproval", "Error al cargar el producto: " + databaseError.getMessage());
                        mostrarDetallesSolicitud("Desconocido", "Desconocido");
                    }
                });
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("LoanApproval", "Error al cargar el usuario: " + databaseError.getMessage());
                mostrarDetallesSolicitud("Desconocido", "Desconocido");
            }
        });
    }

    private void mostrarDetallesSolicitud(String userName, String productName) {
        String detalles = "ID Solicitud: " + requestId +
                "\nSolicitante: " + userName +
                "\nProducto: " + productName +
                "\nCantidad: " + quantity;
        tvDetallesSolicitud.setText(detalles);
        btnTomarFoto.setVisibility(View.VISIBLE);
        ivEvidencia.setVisibility(View.VISIBLE);
    }

    private void aprobarSolicitud() {
        progressBar.setVisibility(View.VISIBLE);
        btnAprobar.setEnabled(false);
        btnRechazar.setEnabled(false);
        btnTomarFoto.setEnabled(false);

        Uri uploadUri = Uri.fromFile(new File(currentPhotoPath));

        StorageReference photoRef = mStorageRef.child("loan_evidences/" + requestId + ".jpg");
        photoRef.putFile(uploadUri)
                .addOnSuccessListener(taskSnapshot -> {
                    photoRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        String photoUrl = uri.toString();
                        mDatabase.child("loan_requests").child(requestId).child("status").setValue("aprobado");
                        mDatabase.child("loan_requests").child(requestId).child("photoUrl").setValue(photoUrl);

                        DatabaseReference productRef = mDatabase.child("products").child(productId);
                        productRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                Product product = dataSnapshot.getValue(Product.class);
                                if (product != null) {
                                    int newQuantity = product.getQuantity() - quantity;
                                    if (newQuantity >= 0) {
                                        productRef.child("quantity").setValue(newQuantity);
                                        Toast.makeText(LoanApprovalActivity.this, "Solicitud Aprobada y stock actualizado.", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(LoanApprovalActivity.this, "Error: Stock insuficiente para completar la solicitud.", Toast.LENGTH_LONG).show();
                                    }
                                }
                                progressBar.setVisibility(View.GONE);
                                finish();
                            }
                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                Toast.makeText(LoanApprovalActivity.this, "Error de base de datos al actualizar stock.", Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                                finish();
                            }
                        });
                    });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(LoanApprovalActivity.this, "Error al subir la foto: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                    btnAprobar.setEnabled(true);
                    btnRechazar.setEnabled(true);
                    btnTomarFoto.setEnabled(true);
                });
    }

    private void rechazarSolicitud() {
        mDatabase.child("loan_requests").child(requestId).child("status").setValue("rechazado")
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(LoanApprovalActivity.this, "Solicitud Rechazada.", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(LoanApprovalActivity.this, "Error al rechazar la solicitud.", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                Log.e("Camera", "Error creating image file: " + ex.getMessage());
                Toast.makeText(this, "Error al crear archivo de imagen.", Toast.LENGTH_SHORT).show();
            }
            if (photoFile != null) {
                Uri photoUri = FileProvider.getUriForFile(this,
                        "com.yj.tinventario.fileprovider",
                        photoFile);
                currentPhotoPath = photoFile.getAbsolutePath();
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            }
        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            if (currentPhotoPath != null) {
                // Usa Glide para cargar la imagen en el ImageView
                Glide.with(this)
                        .load(currentPhotoPath)
                        .into(ivEvidencia);

                Toast.makeText(this, "Foto tomada con éxito.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No se pudo obtener la imagen.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                PERMISSION_CAMERA_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_CAMERA_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();
            } else {
                Toast.makeText(this, "El permiso de cámara es necesario para tomar la foto.", Toast.LENGTH_LONG).show();
            }
        }
    }
}