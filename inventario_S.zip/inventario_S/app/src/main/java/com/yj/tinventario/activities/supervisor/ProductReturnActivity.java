package com.yj.tinventario.activities.supervisor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.yj.tinventario.R;
import com.yj.tinventario.models.LoanRequest;
import com.yj.tinventario.models.Product;
import com.yj.tinventario.models.User;
import com.yj.tinventario.adapters.LoanRequestAdapter;

import java.util.ArrayList;
import java.util.List;

// Importante: La clase ahora implementa la interfaz de OnItemClickListener
public class ProductReturnActivity extends AppCompatActivity implements LoanRequestAdapter.OnItemClickListener {

    private EditText etSearchQuery;
    private Button btnSearch;
    private Button btnConfirmarDevolucion; // Este botón ya no se usará
    private TextView tvLoanDetails; // Este TextView ya no se usará
    private RecyclerView rvPendingLoans;

    private LoanRequestAdapter adapter;
    private List<LoanRequest> pendingRequestsList;

    private DatabaseReference mDatabase;
    private LoanRequest selectedRequest; // Para almacenar el préstamo seleccionado

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_return);

        // Inicializar vistas
        etSearchQuery = findViewById(R.id.etSearchQuery);
        btnSearch = findViewById(R.id.btnSearch);
        btnConfirmarDevolucion = findViewById(R.id.btnConfirmarDevolucion);
        tvLoanDetails = findViewById(R.id.tvLoanDetails);
        rvPendingLoans = findViewById(R.id.rvPendingLoans);
        rvPendingLoans.setLayoutManager(new LinearLayoutManager(this));

        pendingRequestsList = new ArrayList<>();
        adapter = new LoanRequestAdapter(this, pendingRequestsList);
        rvPendingLoans.setAdapter(adapter);

        // Asigna el listener de tap normal
        adapter.setOnItemClickListener(this);

        // Inicializar Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference();

        btnSearch.setOnClickListener(v -> handleSearch());
        // El botón btnConfirmarDevolucion ya no es necesario, lo puedes ocultar o eliminar del layout
        btnConfirmarDevolucion.setVisibility(View.GONE);
        tvLoanDetails.setVisibility(View.GONE);

        // Cargar la lista de préstamos pendientes por defecto
        loadPendingLoans();
    }

    private void handleSearch() {
        String query = etSearchQuery.getText().toString().trim();
        if (TextUtils.isEmpty(query)) {
            Toast.makeText(this, "Por favor, ingrese un ID o nombre.", Toast.LENGTH_SHORT).show();
            loadPendingLoans(); // Cargar la lista completa si el campo está vacío
            return;
        }

        // Determinar el tipo de búsqueda (por ID o por nombre)
        if (query.startsWith("req")) { // Ejemplo: si los IDs de préstamo comienzan con "req"
            buscarPrestamoPorId(query);
        } else {
            buscarPrestamoPorNombre(query);
        }
    }

    private void buscarPrestamoPorId(String loanId) {
        Query query = mDatabase.child("loan_requests").orderByKey().equalTo(loanId);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                pendingRequestsList.clear();
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        LoanRequest request = snapshot.getValue(LoanRequest.class);
                        if (request != null && request.getStatus().equals("aprobado")) {
                            request.setRequestId(snapshot.getKey());
                            pendingRequestsList.add(request);
                        }
                    }
                }
                adapter.notifyDataSetChanged();
                if (pendingRequestsList.isEmpty()) {
                    Toast.makeText(ProductReturnActivity.this, "Préstamo no encontrado o no pendiente.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(ProductReturnActivity.this, "Error de búsqueda por ID: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void buscarPrestamoPorNombre(String userName) {
        Query userQuery = mDatabase.child("users").orderByChild("nombre").equalTo(userName);
        userQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                pendingRequestsList.clear();
                if (dataSnapshot.exists()) {
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String userId = userSnapshot.getKey();
                        Query loanQuery = mDatabase.child("loan_requests").orderByChild("userId").equalTo(userId);
                        loanQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot loansSnapshot) {
                                for (DataSnapshot loanSnap : loansSnapshot.getChildren()) {
                                    LoanRequest loan = loanSnap.getValue(LoanRequest.class);
                                    if (loan != null && loan.getStatus().equals("aprobado")) {
                                        loan.setRequestId(loanSnap.getKey());
                                        pendingRequestsList.add(loan);
                                    }
                                }
                                adapter.notifyDataSetChanged();
                                if (pendingRequestsList.isEmpty()) {
                                    Toast.makeText(ProductReturnActivity.this, "No se encontraron préstamos pendientes para este usuario.", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                Toast.makeText(ProductReturnActivity.this, "Error al buscar préstamos.", Toast.LENGTH_SHORT).show();
                            }
                        });
                        // Solo procesar el primer usuario encontrado
                        break;
                    }
                } else {
                    Toast.makeText(ProductReturnActivity.this, "Usuario no encontrado.", Toast.LENGTH_SHORT).show();
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(ProductReturnActivity.this, "Error al buscar usuario: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadPendingLoans() {
        Query query = mDatabase.child("loan_requests").orderByChild("status").equalTo("aprobado");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                pendingRequestsList.clear();
                for (DataSnapshot loanSnapshot : dataSnapshot.getChildren()) {
                    LoanRequest loan = loanSnapshot.getValue(LoanRequest.class);
                    if (loan != null && loan.getStatus().equals("aprobado")) {
                        loan.setRequestId(loanSnapshot.getKey());
                        pendingRequestsList.add(loan);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(ProductReturnActivity.this, "Error al cargar préstamos pendientes.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // El método que se activa al hacer un solo tap en un item
    @Override
    public void onItemClick(LoanRequest request) {
        selectedRequest = request; // Almacena el préstamo para la devolución

        new AlertDialog.Builder(this)
                .setTitle("Confirmar Devolución")
                .setMessage("¿Desea confirmar la devolución del préstamo " + request.getRequestId() + "?")
                .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        confirmarDevolucion(); // Llama a la lógica de devolución
                    }
                })
                .setNegativeButton(android.R.string.cancel, null) // No hace nada al cancelar
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void confirmarDevolucion() {
        if (selectedRequest != null) {
            // Actualizar el estado del préstamo en Firebase a "devuelto"
            mDatabase.child("loan_requests").child(selectedRequest.getRequestId()).child("status").setValue("devuelto")
                    .addOnSuccessListener(aVoid -> {
                        // Revertir el stock del producto
                        DatabaseReference productRef = mDatabase.child("products").child(selectedRequest.getProductId());
                        productRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                Product product = dataSnapshot.getValue(Product.class);
                                if (product != null) {
                                    int newQuantity = product.getQuantity() + selectedRequest.getQuantity();
                                    productRef.child("quantity").setValue(newQuantity);
                                    Toast.makeText(ProductReturnActivity.this, "Devolución confirmada y stock actualizado.", Toast.LENGTH_SHORT).show();
                                }
                                // Limpiar la vista y recargar la lista
                                clearDetailsView();
                                loadPendingLoans();
                            }
                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                Toast.makeText(ProductReturnActivity.this, "Error de base de datos al actualizar stock.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(ProductReturnActivity.this, "Error al confirmar la devolución.", Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void clearDetailsView() {
        // Los elementos de la interfaz ya están ocultos por defecto
        selectedRequest = null;
    }
}