package com.yj.tinventario.models;

public class LoanRequest {
    private String requestId;
    private String userId;
    private String productId;
    private int quantity;
    private long timestamp;
    private String status; // "pendiente", "aprobado", "devuelto", "rechazado"

    public LoanRequest() {
        // Constructor vacío requerido para Firebase
    }

    public LoanRequest(String requestId, String userId, String productId, int quantity, long timestamp, String status) {
        this.requestId = requestId;
        this.userId = userId;
        this.productId = productId;
        this.quantity = quantity;
        this.timestamp = timestamp;
        this.status = status;
    }

    // Getters y Setters
    public String getRequestId() { return requestId; }
    public void setRequestId(String requestId) { this.requestId = requestId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // Inside the LoanRequest class

    private String photoUrl; // Add this field

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }
}