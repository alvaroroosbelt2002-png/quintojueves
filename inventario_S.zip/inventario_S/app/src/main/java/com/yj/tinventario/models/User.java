package com.yj.tinventario.models;

public class User {
    private String userId; // El ID de Firebase, se asigna por separado
    private String nombre;
    private String apellido;
    private String email;
    private String role;

    public User() {
        // Constructor vacío requerido para Firebase
    }

    public User(String nombre, String apellido, String email, String role) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.role = role;
    }

    // Getters
    public String getUserId() {
        return userId;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    // **NUEVO MÉTODO**
    public String getFullName() {
        // Combina el nombre y el apellido para obtener el nombre completo
        return nombre + " " + apellido;
    }

    // Setters
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRole(String role) {
        this.role = role;
    }

}