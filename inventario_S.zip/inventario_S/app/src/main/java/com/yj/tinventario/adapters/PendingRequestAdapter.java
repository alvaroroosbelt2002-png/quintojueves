package com.yj.tinventario.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.yj.tinventario.R;
import com.yj.tinventario.models.LoanRequest;
import com.yj.tinventario.models.PendingRequestDisplay; // Importar el nuevo modelo
import java.util.List;

public class PendingRequestAdapter extends RecyclerView.Adapter<PendingRequestAdapter.PendingRequestViewHolder> {

    private List<PendingRequestDisplay> pendingRequestsDisplayList; // Lista del nuevo modelo
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(LoanRequest request);
    }

    public PendingRequestAdapter(List<PendingRequestDisplay> pendingRequestsDisplayList, OnItemClickListener listener) {
        this.pendingRequestsDisplayList = pendingRequestsDisplayList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PendingRequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pending_request, parent, false);
        return new PendingRequestViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PendingRequestViewHolder holder, int position) {
        PendingRequestDisplay displayItem = pendingRequestsDisplayList.get(position);
        LoanRequest loanRequest = displayItem.getLoanRequest();

        // Ahora se muestran los nombres obtenidos de las consultas anidadas
        holder.tvNombreCliente.setText(displayItem.getUserName());
        holder.tvNombreProducto.setText(displayItem.getProductName());
        holder.tvCantidad.setText("Cantidad: " + loanRequest.getQuantity());

        holder.itemView.setOnClickListener(v -> listener.onItemClick(loanRequest));
    }

    @Override
    public int getItemCount() {
        return pendingRequestsDisplayList.size();
    }

    static class PendingRequestViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombreCliente, tvNombreProducto, tvCantidad;

        public PendingRequestViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombreCliente = itemView.findViewById(R.id.tvNombreCliente);
            tvNombreProducto = itemView.findViewById(R.id.tvNombreProducto);
            tvCantidad = itemView.findViewById(R.id.tvCantidad);
        }
    }
}