package com.yj.tinventario.activities.instructor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.yj.tinventario.R;
import com.yj.tinventario.activities.common.LoginActivity;

public class InstructorDashboardActivity extends AppCompatActivity {

    private Button btnVerInventario, btnSolicitarPrestamo, btnHistorialPrestamos, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor_dashboard);

        // Inicializar vistas
        btnVerInventario = findViewById(R.id.btnVerInventario);
        btnSolicitarPrestamo = findViewById(R.id.btnSolicitarPrestamo);
        btnHistorialPrestamos = findViewById(R.id.btnHistorialPrestamos);
        btnLogout = findViewById(R.id.btnLogout);

        // Listener para el botón de Ver Inventario
        btnVerInventario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar a la pantalla de Inventario
                Intent intent = new Intent(InstructorDashboardActivity.this, InventoryActivity.class);
                startActivity(intent);
            }
        });

        // Listener para el botón de Solicitar Préstamo
        btnSolicitarPrestamo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar a la pantalla de Solicitud de Préstamo
                Intent intent = new Intent(InstructorDashboardActivity.this, RequestLoanActivity.class);
                startActivity(intent);
            }
        });

        // Listener para el botón de Historial de Préstamos
        btnHistorialPrestamos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar a la pantalla de Historial de Préstamos
                Intent intent = new Intent(InstructorDashboardActivity.this, LoanHistoryActivity.class);
                startActivity(intent);
            }
        });

        // Listener para el botón de Cerrar Sesión
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lógica para cerrar sesión (ej. con Firebase)
                Toast.makeText(InstructorDashboardActivity.this, "Sesión cerrada.", Toast.LENGTH_SHORT).show();

                // Navegar a la pantalla de Login y cerrar las actividades anteriores
                Intent intent = new Intent(InstructorDashboardActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}