package com.yj.tinventario.models;

public class PendingRequestDisplay {
    private LoanRequest loanRequest;
    private String userName;
    private String productName;

    public PendingRequestDisplay() {
        // Constructor vacío requerido para Firebase, aunque no se usará aquí
    }

    public PendingRequestDisplay(LoanRequest loanRequest, String userName, String productName) {
        this.loanRequest = loanRequest;
        this.userName = userName;
        this.productName = productName;
    }

    public LoanRequest getLoanRequest() {
        return loanRequest;
    }

    public String getUserName() {
        return userName;
    }

    public String getProductName() {
        return productName;
    }
}