package com.yj.tinventario.activities.common;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.yj.tinventario.R;
import com.yj.tinventario.activities.admin.AdminDashboardActivity;
import com.yj.tinventario.activities.instructor.InstructorDashboardActivity;
import com.yj.tinventario.activities.supervisor.SupervisorDashboardActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etCorreo, etContrasena, etCodigoAcceso;
    private CheckBox cbSupervisor;
    private Button btnLogin;
    private TextView tvRegistrarse;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etCorreo = findViewById(R.id.etCorreo);
        etContrasena = findViewById(R.id.etContrasena);
        etCodigoAcceso = findViewById(R.id.etCodigoAcceso);
        cbSupervisor = findViewById(R.id.cbSupervisor);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegistrarse = findViewById(R.id.tvRegistrarse);

        etCodigoAcceso.setVisibility(View.GONE);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Lógica para mostrar la casilla del código al marcar el CheckBox
        cbSupervisor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Si se marca, muestra la casilla y cambia el hint
                etCodigoAcceso.setHint("Código de acceso");
                etCodigoAcceso.setVisibility(View.VISIBLE);
            } else {
                // Si se desmarca, oculta la casilla y limpia el texto
                etCodigoAcceso.setVisibility(View.GONE);
                etCodigoAcceso.setText("");
            }
        });

        btnLogin.setOnClickListener(v -> {
            String correo = etCorreo.getText().toString().trim();
            String contrasena = etContrasena.getText().toString().trim();
            String codigoAcceso = etCodigoAcceso.getText().toString().trim();

            if (correo.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Por favor, complete todos los campos.", Toast.LENGTH_SHORT).show();
                return;
            }

            // AHORA LA LÓGICA DE VERIFICACIÓN SE HACE DESPUÉS DE OBTENER EL ROL
            loginUser(correo, contrasena, codigoAcceso);
        });

        tvRegistrarse.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private void loginUser(String email, String password, String accessCode) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            checkUserRole(user.getUid(), accessCode);
                        }
                    } else {
                        Toast.makeText(LoginActivity.this, "Autenticación fallida. Verifique sus credenciales.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void checkUserRole(String userId, String accessCode) {
        mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String role = dataSnapshot.child("role").getValue(String.class);
                    if (role == null) {
                        role = "Instructor";
                    }

                    if ("Instructor".equalsIgnoreCase(role)) {
                        startActivity(new Intent(LoginActivity.this, InstructorDashboardActivity.class));
                        finish();
                    } else if ("Supervisor".equalsIgnoreCase(role)) {
                        checkSupervisorAccessCode(userId, accessCode);
                    } else if ("Administrador".equalsIgnoreCase(role)) {
                        // AQUÍ, SI EL ADMIN NO TIENE EL CAMPO DE CÓDIGO
                        // Y NO SE HA ESCRITO NADA EN EL CAMPO DE TEXTO, SE MOSTRARÁ UN ERROR.
                        checkAdminAccessCode(userId, accessCode);
                    } else {
                        Toast.makeText(LoginActivity.this, "Rol de usuario desconocido.", Toast.LENGTH_SHORT).show();
                        mAuth.signOut();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Datos de usuario no encontrados.", Toast.LENGTH_SHORT).show();
                    mAuth.signOut();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(LoginActivity.this, "Error al obtener el rol: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                mAuth.signOut();
            }
        });
    }

    // Lógica revisada para verificar el código del supervisor
    private void checkSupervisorAccessCode(String userId, String accessCode) {
        // No verificamos el CheckBox aquí.
        // En su lugar, el usuario debe haber escrito un código
        if (accessCode.isEmpty()) {
            Toast.makeText(LoginActivity.this, "El supervisor requiere un código de acceso.", Toast.LENGTH_SHORT).show();
            mAuth.signOut();
            return;
        }

        mDatabase.child("users").child(userId).child("accessCode").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String storedCode = dataSnapshot.getValue(String.class);

                if (storedCode != null && storedCode.equals(accessCode)) {
                    Toast.makeText(LoginActivity.this, "¡Inicio de sesión exitoso!", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(LoginActivity.this, SupervisorDashboardActivity.class));
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Código de acceso incorrecto.", Toast.LENGTH_SHORT).show();
                    mAuth.signOut();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(LoginActivity.this, "Error al verificar el código: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                mAuth.signOut();
            }
        });
    }

    // Lógica para verificar el código del administrador
    private void checkAdminAccessCode(String userId, String accessCode) {
        if (accessCode.isEmpty()) {
            Toast.makeText(LoginActivity.this, "El administrador requiere un código de acceso.", Toast.LENGTH_SHORT).show();
            mAuth.signOut();
            return;
        }

        mDatabase.child("users").child(userId).child("accessCode").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String storedCode = dataSnapshot.getValue(String.class);

                if (storedCode != null && storedCode.equals(accessCode)) {
                    Toast.makeText(LoginActivity.this, "¡Inicio de sesión de Administrador exitoso!", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(LoginActivity.this, AdminDashboardActivity.class));
                    finish();
                } else {
                    Toast.makeText(LoginActivity.this, "Código de acceso de Administrador incorrecto.", Toast.LENGTH_SHORT).show();
                    mAuth.signOut();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(LoginActivity.this, "Error al verificar el código: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                mAuth.signOut();
            }
        });
    }
}