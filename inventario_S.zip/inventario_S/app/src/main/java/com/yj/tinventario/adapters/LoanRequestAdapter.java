package com.yj.tinventario.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yj.tinventario.R;
import com.yj.tinventario.models.LoanRequest;
import com.yj.tinventario.models.User;
import com.yj.tinventario.models.Product;
import java.util.List;
import java.util.Locale;

public class LoanRequestAdapter extends RecyclerView.Adapter<LoanRequestAdapter.LoanRequestViewHolder> {

    private final List<LoanRequest> loanRequests;
    private OnItemClickListener listener;
    private DatabaseReference mDatabase;

    public interface OnItemClickListener {
        void onItemClick(LoanRequest loanRequest);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public LoanRequestAdapter(Context context, List<LoanRequest> loanRequests) {
        this.loanRequests = loanRequests;
        this.mDatabase = FirebaseDatabase.getInstance().getReference();
    }

    @NonNull
    @Override
    public LoanRequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_loan_request_supervisor, parent, false);
        return new LoanRequestViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LoanRequestViewHolder holder, int position) {
        LoanRequest request = loanRequests.get(position);
        holder.bind(request);
    }

    @Override
    public int getItemCount() {
        return loanRequests.size();
    }

    // Método para actualizar la lista de datos del adaptador
    public void setLoanRequests(List<LoanRequest> newLoanRequests) {
        this.loanRequests.clear();
        this.loanRequests.addAll(newLoanRequests);
        notifyDataSetChanged();
    }

    public class LoanRequestViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvSolicitante;
        private final TextView tvProductoPrestado;
        private final TextView tvCantidad;
        private final TextView tvFechaSolicitud;
        private final TextView tvEstado;

        public LoanRequestViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSolicitante = itemView.findViewById(R.id.tvSolicitante);
            tvProductoPrestado = itemView.findViewById(R.id.tvProductoPrestado);
            tvCantidad = itemView.findViewById(R.id.tvCantidad);
            tvFechaSolicitud = itemView.findViewById(R.id.tvFechaSolicitud);
            tvEstado = itemView.findViewById(R.id.tvEstado);

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(loanRequests.get(position));
                    }
                }
            });
        }

        public void bind(LoanRequest request) {
            tvCantidad.setText(String.format(Locale.getDefault(), "Cantidad: %d", request.getQuantity()));
            tvFechaSolicitud.setText(String.format("Fecha: %s", new java.util.Date(request.getTimestamp()).toString()));
            tvEstado.setText(String.format("Estado: %s", request.getStatus()));

            String userId = request.getUserId();
            if (userId != null && !userId.trim().isEmpty()) {
                mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        User user = dataSnapshot.getValue(User.class);
                        if (user != null && user.getNombre() != null) {
                            tvSolicitante.setText(String.format("Solicitante: %s", user.getNombre()));
                        } else {
                            tvSolicitante.setText("Solicitante: No encontrado");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        tvSolicitante.setText("Solicitante: Error de carga");
                    }
                });
            } else {
                tvSolicitante.setText("Solicitante: No encontrado");
            }

            String productId = request.getProductId();
            if (productId != null && !productId.trim().isEmpty()) {
                mDatabase.child("products").child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Product product = dataSnapshot.getValue(Product.class);
                        if (product != null && product.getName() != null) {
                            tvProductoPrestado.setText(String.format("Producto: %s", product.getName()));
                        } else {
                            tvProductoPrestado.setText("Producto: No encontrado");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        tvProductoPrestado.setText("Producto: Error de carga");
                    }
                });
            } else {
                tvProductoPrestado.setText("Producto: No encontrado");
            }
        }
    }
}