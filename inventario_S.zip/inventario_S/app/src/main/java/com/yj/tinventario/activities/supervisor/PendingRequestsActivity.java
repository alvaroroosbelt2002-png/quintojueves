package com.yj.tinventario.activities.supervisor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.yj.tinventario.R;
import com.yj.tinventario.adapters.LoanRequestAdapter;
import com.yj.tinventario.models.LoanRequest;

import java.util.ArrayList;
import java.util.List;

// Revertido a OnItemClickListener
public class PendingRequestsActivity extends AppCompatActivity implements LoanRequestAdapter.OnItemClickListener {
    private RecyclerView rvPendingRequests;
    private LoanRequestAdapter adapter;
    private List<LoanRequest> pendingRequestsList;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_requests);

        rvPendingRequests = findViewById(R.id.rvPendingRequests);
        rvPendingRequests.setLayoutManager(new LinearLayoutManager(this));

        pendingRequestsList = new ArrayList<>();
        adapter = new LoanRequestAdapter(this, pendingRequestsList);

        // Revertido a setOnItemClickListener
        adapter.setOnItemClickListener(this);
        rvPendingRequests.setAdapter(adapter);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        loadPendingRequests();
    }

    private void loadPendingRequests() {
        Query query = mDatabase.child("loan_requests").orderByChild("status").equalTo("pendiente");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                pendingRequestsList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    LoanRequest request = snapshot.getValue(LoanRequest.class);
                    if (request != null) {
                        request.setRequestId(snapshot.getKey());
                        pendingRequestsList.add(request);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("PendingRequests", "Error al cargar solicitudes: " + databaseError.getMessage());
                Toast.makeText(PendingRequestsActivity.this, "Error al cargar solicitudes.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Revertido al método onItemClick
    @Override
    public void onItemClick(LoanRequest loanRequest) {
        // Al hacer clic en una tarjeta, se abre la actividad de aprobación
        Intent intent = new Intent(PendingRequestsActivity.this, LoanApprovalActivity.class);
        intent.putExtra("requestId", loanRequest.getRequestId());
        intent.putExtra("userId", loanRequest.getUserId());
        intent.putExtra("productId", loanRequest.getProductId());
        intent.putExtra("quantity", loanRequest.getQuantity());
        startActivity(intent);
    }
}