package com.yj.tinventario.activities.common;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

// Importaciones de Firebase para Authentication y Realtime Database
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.yj.tinventario.R;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private EditText etNombreRegistro, etApellidoRegistro, etCelularRegistro; // Nuevos campos
    private EditText etCorreoRegistro, etContrasenaRegistro, etConfirmarContrasena;
    private Button btnRegistrar;
    private TextView tvYaTengoCuenta;

    // Instancias de Firebase
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar vistas
        etNombreRegistro = findViewById(R.id.etNombreRegistro);
        etApellidoRegistro = findViewById(R.id.etApellidoRegistro);
        etCelularRegistro = findViewById(R.id.etCelularRegistro);
        etCorreoRegistro = findViewById(R.id.etCorreoRegistro);
        etContrasenaRegistro = findViewById(R.id.etContrasenaRegistro);
        etConfirmarContrasena = findViewById(R.id.etConfirmarContrasena);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        tvYaTengoCuenta = findViewById(R.id.tvYaTengoCuenta);

        // Inicializar instancias de Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Listener para el botón de Registrar
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = etNombreRegistro.getText().toString().trim();
                String apellido = etApellidoRegistro.getText().toString().trim();
                String celular = etCelularRegistro.getText().toString().trim();
                String correo = etCorreoRegistro.getText().toString().trim();
                String contrasena = etContrasenaRegistro.getText().toString().trim();
                String confirmarContrasena = etConfirmarContrasena.getText().toString().trim();

                if (nombre.isEmpty() || apellido.isEmpty() || celular.isEmpty() || correo.isEmpty() || contrasena.isEmpty() || confirmarContrasena.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Por favor, complete todos los campos.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!contrasena.equals(confirmarContrasena)) {
                    Toast.makeText(RegisterActivity.this, "Las contraseñas no coinciden.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Llamar al método de registro con Firebase, pasando los nuevos datos
                registerUser(nombre, apellido, celular, correo, contrasena);
            }
        });

        // Listener para el texto de "Ya tengo una cuenta"
        tvYaTengoCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void registerUser(String nombre, String apellido, String celular, String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Registro exitoso
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            // Guardar el rol y los nuevos datos del usuario en la base de datos de Realtime
                            saveUserData(user.getUid(), nombre, apellido, celular, email);
                        }
                    } else {
                        // Si el registro falla, mostrar un mensaje de error
                        Toast.makeText(RegisterActivity.this, "Error de registro: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void saveUserData(String userId, String nombre, String apellido, String celular, String email) {
        // Crear un mapa de datos para el nuevo usuario
        Map<String, Object> user = new HashMap<>();
        user.put("nombre", nombre);
        user.put("apellido", apellido);
        user.put("celular", celular);
        user.put("email", email);
        user.put("role", "Instructor"); // Rol por defecto

        // Guardar el nuevo usuario en la ruta "users" de Realtime Database
        // La clave es el ID de usuario único (UID)
        mDatabase.child("users").child(userId).setValue(user)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(RegisterActivity.this, "¡Registro exitoso! Ahora puede iniciar sesión.", Toast.LENGTH_LONG).show();
                    // Después del registro exitoso, volver a la pantalla de Login
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(RegisterActivity.this, "Error al guardar los datos del usuario.", Toast.LENGTH_SHORT).show();
                });
    }
}