package com.yj.tinventario.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yj.tinventario.R;
import com.yj.tinventario.models.LoanRequest;
import com.yj.tinventario.models.Product;
import com.yj.tinventario.models.User;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Date;
import java.util.Locale;

public class SupervisorLoanHistoryAdapter extends RecyclerView.Adapter<SupervisorLoanHistoryAdapter.SupervisorLoanHistoryViewHolder> {

    // 1. Define la interfaz para manejar clics
    public interface OnItemClickListener {
        void onItemClick(LoanRequest request);
    }

    private final List<LoanRequest> loanRequestList;
    private final OnItemClickListener listener;
    private final DatabaseReference mDatabase;

    // 2. Modifica el constructor para recibir el listener
    public SupervisorLoanHistoryAdapter(List<LoanRequest> loanRequestList, OnItemClickListener listener) {
        this.loanRequestList = loanRequestList;
        this.listener = listener;
        this.mDatabase = FirebaseDatabase.getInstance().getReference();
    }

    @NonNull
    @Override
    public SupervisorLoanHistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_loan_request_supervisor, parent, false);
        return new SupervisorLoanHistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SupervisorLoanHistoryViewHolder holder, int position) {
        LoanRequest request = loanRequestList.get(position);

        fetchUserName(holder.tvSolicitante, request.getUserId());
        fetchProductName(holder.tvProductoPrestado, request.getProductId());

        holder.tvCantidad.setText("Cantidad: " + request.getQuantity());

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        holder.tvFechaSolicitud.setText("Fecha: " + sdf.format(new Date(request.getTimestamp())));

        // Verificación de nulos para evitar errores
        String status = request.getStatus() != null ? request.getStatus() : "desconocido";
        holder.tvEstado.setText("Estado: " + status.toUpperCase());

        int color;
        switch (status.toLowerCase()) {
            case "aprobado":
                color = android.graphics.Color.parseColor("#4CAF50"); // Green
                break;
            case "devuelto":
                color = android.graphics.Color.parseColor("#3F51B5"); // Blue
                break;
            case "rechazado":
                color = android.graphics.Color.parseColor("#F44336"); // Red
                break;
            case "pendiente":
            default:
                color = android.graphics.Color.parseColor("#FF9800"); // Orange
                break;
        }
        holder.tvEstado.setTextColor(color);
    }

    @Override
    public int getItemCount() {
        return loanRequestList.size();
    }

    private void fetchUserName(TextView textView, String userId) {
        if (userId == null) {
            textView.setText("Solicitante: N/A");
            return;
        }
        mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user = snapshot.getValue(User.class);
                if (user != null) {
                    textView.setText("Solicitante: " + user.getNombre() + " " + user.getApellido());
                } else {
                    textView.setText("Solicitante: Usuario no encontrado");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                textView.setText("Solicitante: Error de carga");
            }
        });
    }

    private void fetchProductName(TextView textView, String productId) {
        if (productId == null) {
            textView.setText("Producto: N/A");
            return;
        }
        mDatabase.child("products").child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Product product = snapshot.getValue(Product.class);
                if (product != null) {
                    textView.setText("Producto: " + product.getName());
                } else {
                    textView.setText("Producto: Producto no encontrado");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                textView.setText("Producto: Error de carga");
            }
        });
    }

    public class SupervisorLoanHistoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvSolicitante, tvProductoPrestado, tvCantidad, tvFechaSolicitud, tvEstado;

        public SupervisorLoanHistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSolicitante = itemView.findViewById(R.id.tvSolicitante);
            tvProductoPrestado = itemView.findViewById(R.id.tvProductoPrestado);
            tvCantidad = itemView.findViewById(R.id.tvCantidad);
            tvFechaSolicitud = itemView.findViewById(R.id.tvFechaSolicitud);
            tvEstado = itemView.findViewById(R.id.tvEstado);

            // 3. Agrega el listener de clic al elemento
            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onItemClick(loanRequestList.get(position));
                }
            });
        }
    }
}