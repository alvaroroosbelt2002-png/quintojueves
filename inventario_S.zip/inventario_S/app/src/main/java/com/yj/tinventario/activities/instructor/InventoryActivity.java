package com.yj.tinventario.activities.instructor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.yj.tinventario.R;
import com.yj.tinventario.adapters.ProductAdapter;
import com.yj.tinventario.models.Product;

// Importaciones de Firebase Realtime Database
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList;

    // Instancia de Firebase Realtime Database
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Inicializar la instancia de Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference("products");

        // Inicializar el RecyclerView y la lista de productos
        recyclerView = findViewById(R.id.recyclerViewInventario);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        productList = new ArrayList<>();
        adapter = new ProductAdapter(productList);
        recyclerView.setAdapter(adapter);

        // Llamar al método para cargar los datos de Firebase
        loadInventoryFromFirebase();
    }

    private void loadInventoryFromFirebase() {
        // Añadir un ValueEventListener para escuchar cambios en los datos
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Limpiar la lista para evitar duplicados
                productList.clear();

                // Recorrer los productos en la base de datos
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    // Convertir el DataSnapshot a un objeto Product
                    Product product = postSnapshot.getValue(Product.class);
                    if (product != null) {
                        // Establecer la clave como ID del producto
                        product.setProductId(postSnapshot.getKey());
                        productList.add(product);
                    }
                }

                // Notificar al adaptador que los datos han cambiado
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Manejar errores de la base de datos
                Toast.makeText(InventoryActivity.this, "Error al cargar el inventario: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}