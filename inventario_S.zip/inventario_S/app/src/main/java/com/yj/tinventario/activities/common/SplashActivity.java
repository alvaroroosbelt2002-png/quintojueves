package com.yj.tinventario.activities.common;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.yj.tinventario.R;
import com.yj.tinventario.activities.admin.AdminDashboardActivity;
import com.yj.tinventario.activities.supervisor.SupervisorDashboardActivity;
import com.yj.tinventario.activities.instructor.InstructorDashboardActivity;

public class SplashActivity extends AppCompatActivity {

    private static int SPLASH_TIME_OUT = 2000;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Se usa un Handler para esperar un tiempo antes de iniciar la lógica
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Comprueba si ya hay una sesión activa de Firebase
                FirebaseUser currentUser = mAuth.getCurrentUser();

                // Agrega esta línea para depurar y ver si el usuario está logueado
                if (currentUser != null) {
                    Log.d("SplashActivity", "Usuario logueado: " + currentUser.getUid());
                    checkUserRoleAndRedirect(currentUser.getUid());
                } else {
                    Log.d("SplashActivity", "No hay usuario logueado. Redirigiendo a LoginActivity.");
                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    finish();
                }
            }
        }, SPLASH_TIME_OUT);
    }

    private void checkUserRoleAndRedirect(String userId) {
        // Consulta la base de datos de Firebase para obtener el rol del usuario de forma asíncrona
        mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String role = dataSnapshot.child("role").getValue(String.class);
                Intent intent;
                if (role != null) {
                    switch (role) {
                        case "admin":
                            intent = new Intent(SplashActivity.this, AdminDashboardActivity.class);
                            break;
                        case "supervisor":
                            intent = new Intent(SplashActivity.this, SupervisorDashboardActivity.class);
                            break;
                        case "instructor":
                            intent = new Intent(SplashActivity.this, InstructorDashboardActivity.class);
                            break;
                        default:
                            // Rol desconocido, redirige al login
                            intent = new Intent(SplashActivity.this, LoginActivity.class);
                            break;
                    }
                } else {
                    // El rol no existe en la base de datos, redirige al login
                    Log.e("SplashActivity", "Rol del usuario nulo. Redirigiendo a LoginActivity.");
                    intent = new Intent(SplashActivity.this, LoginActivity.class);
                }
                startActivity(intent);
                finish();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Maneja cualquier error de base de datos
                Log.e("SplashActivity", "Error al leer el rol del usuario: " + databaseError.getMessage());
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                finish();
            }
        });
    }
}