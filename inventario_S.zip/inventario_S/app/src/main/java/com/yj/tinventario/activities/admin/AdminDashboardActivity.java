package com.yj.tinventario.activities.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.yj.tinventario.R;
import com.yj.tinventario.activities.common.LoginActivity;

public class AdminDashboardActivity extends AppCompatActivity {

    private Button btnGestionUsuarios, btnGenerarReportes, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        // Inicializar vistas
        btnGestionUsuarios = findViewById(R.id.btnGestionUsuarios);
        btnGenerarReportes = findViewById(R.id.btnGenerarReportes);
        btnLogout = findViewById(R.id.btnLogout);

        // Listener para el botón de Gestión de Usuarios
        btnGestionUsuarios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardActivity.this, UserManagementActivity.class);
                startActivity(intent);
            }
        });

        // Listener para el botón de Generar Reportes
        btnGenerarReportes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardActivity.this, ReportsActivity.class);
                startActivity(intent);
            }
        });

        // Listener para el botón de Cerrar Sesión
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lógica para cerrar sesión
                Toast.makeText(AdminDashboardActivity.this, "Sesión de administrador cerrada.", Toast.LENGTH_SHORT).show();

                // Navegar a la pantalla de Login y limpiar el historial
                Intent intent = new Intent(AdminDashboardActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}