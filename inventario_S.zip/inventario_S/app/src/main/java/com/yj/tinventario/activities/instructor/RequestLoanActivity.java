package com.yj.tinventario.activities.instructor;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.yj.tinventario.R;
import com.yj.tinventario.models.Product;
import com.yj.tinventario.models.LoanRequest;

// Importaciones de Firebase
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class RequestLoanActivity extends AppCompatActivity {

    private Spinner spinnerProductos;
    private TextView tvStockDisponible;
    private EditText etCantidadSolicitada;
    private Button btnSolicitar;

    private List<Product> productList;
    private Product selectedProduct;

    // Instancias de Firebase
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_loan);

        // Inicializar vistas
        spinnerProductos = findViewById(R.id.spinnerProductos);
        tvStockDisponible = findViewById(R.id.tvStockDisponible);
        etCantidadSolicitada = findViewById(R.id.etCantidadSolicitada);
        btnSolicitar = findViewById(R.id.btnSolicitar);

        // Inicializar instancias de Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Inicializar la lista y el adaptador para el Spinner
        productList = new ArrayList<>();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new ArrayList<>());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerProductos.setAdapter(adapter);

        // Cargar productos desde Firebase
        loadProductsFromFirebase(adapter);

        // Listener para la selección en el Spinner
        spinnerProductos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedProduct = productList.get(position);
                updateStockDisplay(selectedProduct.getQuantity());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No hacer nada
            }
        });

        // Listener para el botón de solicitar
        btnSolicitar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                solicitarPrestamo();
            }
        });
    }

    private void loadProductsFromFirebase(final ArrayAdapter<String> adapter) {
        mDatabase.child("products").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                productList.clear();
                adapter.clear();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Product product = postSnapshot.getValue(Product.class);
                    if (product != null) {
                        product.setProductId(postSnapshot.getKey());
                        productList.add(product);
                        adapter.add(product.getName());
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(RequestLoanActivity.this, "Error al cargar productos: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateStockDisplay(int quantity) {
        tvStockDisponible.setText("Stock disponible: " + quantity + " unidades");
    }

    private void solicitarPrestamo() {
        if (selectedProduct == null) {
            Toast.makeText(this, "Por favor, seleccione un producto.", Toast.LENGTH_SHORT).show();
            return;
        }

        String cantidadStr = etCantidadSolicitada.getText().toString().trim();
        if (cantidadStr.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese una cantidad.", Toast.LENGTH_SHORT).show();
            return;
        }

        int cantidad = Integer.parseInt(cantidadStr);

        // Lógica de validación de stock
        if (cantidad > selectedProduct.getQuantity()) {
            mostrarAlertaStockInsuficiente();
        } else {
            // Lógica para enviar la solicitud a Firebase
            saveLoanRequest(cantidad);
        }
    }

    private void saveLoanRequest(int quantity) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Debe iniciar sesión para solicitar un préstamo.", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = currentUser.getUid();
        String requestId = mDatabase.child("loan_requests").push().getKey();

        LoanRequest loanRequest = new LoanRequest(
                requestId,
                userId,
                selectedProduct.getProductId(),
                quantity,
                System.currentTimeMillis(),
                "pendiente" // El estado inicial de la solicitud
        );

        mDatabase.child("loan_requests").child(requestId).setValue(loanRequest)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(RequestLoanActivity.this, "¡Solicitud enviada con éxito!", Toast.LENGTH_LONG).show();
                    // Opcional: limpiar los campos
                    etCantidadSolicitada.setText("");
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(RequestLoanActivity.this, "Error al enviar la solicitud: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void mostrarAlertaStockInsuficiente() {
        new AlertDialog.Builder(this)
                .setTitle("Stock Insuficiente")
                .setMessage("No hay suficientes unidades de " + selectedProduct.getName() + " disponibles. Stock actual: " + selectedProduct.getQuantity())
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
}