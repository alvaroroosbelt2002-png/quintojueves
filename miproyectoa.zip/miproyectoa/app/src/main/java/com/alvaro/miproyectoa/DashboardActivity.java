package com.alvaro.miproyectoa;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.alvaro.miproyectoa.empresa.EmpresaActivity;
import com.alvaro.miproyectoa.favoritos.FavoritosActivity;
import com.alvaro.miproyectoa.gastos.GastosActivity;
import com.alvaro.miproyectoa.lista_tareas.ListaTareasActivity;
import com.alvaro.miproyectoa.mis_datos.MisDatosActivity;
import com.alvaro.miproyectoa.tareas.TareasActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ValueEventListener;

public class DashboardActivity extends AppCompatActivity {

    CardView cvEmpresa, cvGastos, cvTareas, cvListaTareas, cvFavoritos, cvMisDatos;
    Button btncerrarsesion1, btndesarroladopor;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    TextView tvNombreUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Referencias a vistas
        btncerrarsesion1 = findViewById(R.id.btnCerrarSesion1);
        btndesarroladopor = findViewById(R.id.btnDesarrolladoPor);
        cvEmpresa = findViewById(R.id.cvempresa);
        cvGastos = findViewById(R.id.cvgastos);
        cvTareas = findViewById(R.id.cvtareas);
        cvListaTareas = findViewById(R.id.cvlistatareas);
        cvFavoritos = findViewById(R.id.cvfavoritos);
        cvMisDatos = findViewById(R.id.cvmisdatos);
        tvNombreUsuario = findViewById(R.id.tvNombreUsuario);

        // Firebase
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();

        // Clicks
        cvEmpresa.setOnClickListener(v -> startActivity(new Intent(this, EmpresaActivity.class)));
        cvGastos.setOnClickListener(v -> startActivity(new Intent(this, GastosActivity.class)));
        cvTareas.setOnClickListener(v -> startActivity(new Intent(this, TareasActivity.class)));
        cvListaTareas.setOnClickListener(v -> startActivity(new Intent(this, ListaTareasActivity.class)));
        cvFavoritos.setOnClickListener(v -> startActivity(new Intent(this, FavoritosActivity.class)));
        cvMisDatos.setOnClickListener(v -> startActivity(new Intent(this, MisDatosActivity.class)));

        btndesarroladopor.setOnClickListener(v -> desarrollador());

        btncerrarsesion1.setOnClickListener(v -> cierreSesion());

        // Mostrar nombre de usuario
        if (firebaseUser != null) {
            DatabaseReference ref = FirebaseDatabase.getInstance()
                    .getReference("Usuario")
                    .child(firebaseUser.getUid())
                    .child("nombre");

            ref.get().addOnSuccessListener(snapshot -> {
                if (snapshot.exists()) {
                    String nombre = snapshot.getValue(String.class);
                    tvNombreUsuario.setText(nombre);
                } else {
                    tvNombreUsuario.setText("Usuario");
                }
            }).addOnFailureListener(e -> tvNombreUsuario.setText("Usuario"));
        } else {
            tvNombreUsuario.setText("Usuario Invitado");
        }
    }

    private void cierreSesion() {
        firebaseAuth.signOut();
        startActivity(new Intent(DashboardActivity.this, MainActivity.class));
        Toast.makeText(this, "Cerraste sesión exitosamente", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void desarrollador() {
        Dialog dialogDev = new Dialog(this);
        dialogDev.setContentView(R.layout.dialogo_developer);

        ImageButton btnTelefonodev = dialogDev.findViewById(R.id.btntelefonodev);
        ImageButton btnYoutubedev = dialogDev.findViewById(R.id.btnyoutubedev);
        Button btnVolver = dialogDev.findViewById(R.id.btnvolver);

        btnTelefonodev.setOnClickListener(v -> {
            String numero = "951937072";
            Uri uri = Uri.parse("tel:" + numero);
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        });

        btnYoutubedev.setOnClickListener(v -> {
            Uri uri = Uri.parse("https://www.youtube.com/watch?v=C8l0c7w9jFw");
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        });

        btnVolver.setOnClickListener(v -> dialogDev.dismiss());

        dialogDev.setCancelable(false);
        dialogDev.show();
    }

    @Override
    protected void onStart() {
        super.onStart();
        comprobarSesion();
    }

    private void comprobarSesion() {
        if (firebaseUser == null) {
            startActivity(new Intent(DashboardActivity.this, MainActivity.class));
            finish();
        }
    }
}