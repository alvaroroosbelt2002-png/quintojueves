package com.alvaro.miproyectoa;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.content.Intent;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.regex.Pattern;


public class RegistroActivity extends AppCompatActivity {
    EditText etnombre,etapellido,etcorreo,etpassword,etconfirpassword;
    Button btnregistrar;
    ProgressDialog progressDialog;
    FirebaseAuth firebaseAuth;
    TextView lblvolver;

    String nombre="", apellido="", correo="", password="", confirpassword="";

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        lblvolver = findViewById(R.id.lbl_volver);
        etnombre = findViewById(R.id.etnombre);
        etapellido = findViewById(R.id.etapellido);
        etcorreo = findViewById(R.id.etcorreo);
        etpassword = findViewById(R.id.etpassword);
        etconfirpassword = findViewById(R.id.etconfirpassword);
        btnregistrar = findViewById(R.id.btnregistrar);

        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(RegistroActivity.this);
        progressDialog.setTitle("espere por fabor...");
        progressDialog.setCanceledOnTouchOutside(false);


        lblvolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistroActivity.this, MainActivity.class));
            }
        });
        btnregistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarDatos();
            }
        });
    }


    //SIMULARCION


    private void validarDatos() {
        nombre = etnombre.getText().toString().trim();
        apellido = etapellido.getText().toString().trim();
        correo = etcorreo.getText().toString().trim();
        password = etpassword.getText().toString().trim();
        confirpassword = etconfirpassword.getText().toString().trim();

        if (TextUtils.isEmpty(nombre)) {
            Toast.makeText(this, "El campo nombre esta vacio", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(apellido)) {
            Toast.makeText(this, "El campo apellido esta vacio", Toast.LENGTH_SHORT).show();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
            Toast.makeText(this, "Ingrese correo valido", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(password) || password.length() < 6) {
            Toast.makeText(this, "Ingrese su Password como minimo de 6 caracteres", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(confirpassword) || confirpassword.length() < 6) {
            Toast.makeText(this, "Repita su contraseña para confirmar", Toast.LENGTH_SHORT).show();
        } else if (!password.equals(confirpassword)) {
            Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
        } else {
            registrar();

        }
    }
    private void registrar() {
        progressDialog.setMessage("Registrado usuario");
        progressDialog.show();

        firebaseAuth.createUserWithEmailAndPassword(correo,password)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResultf) {
                        guardausuario();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(RegistroActivity.this,"Ocurrio un problema revisa    los campos",Toast.LENGTH_SHORT).show();

                    }

                });

    }

    private void guardausuario() {
        progressDialog.setMessage("guardando informacion");
        progressDialog.show();

        String uid=firebaseAuth.getUid();
        HashMap<String,String>datausuario=new HashMap<>();
        datausuario.put("uid",uid);
        datausuario.put("nombre",nombre);
        datausuario.put("apellido",apellido);
        datausuario.put("correo",correo);
        datausuario.put("password",password);

        DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference("Usuario");
        databaseReference.child(uid).setValue(datausuario).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused){
                progressDialog.dismiss();
                Toast.makeText(RegistroActivity.this,"Usuario creado con exito",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(RegistroActivity.this,DashboardActivity.class));
                finish();
            }
        }).addOnFailureListener(new OnFailureListener(){
            @Override
            public void onFailure(@NonNull Exception e){
                progressDialog.dismiss();
                Toast.makeText(RegistroActivity.this, "Ocurrio un problema al guardar"+e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}